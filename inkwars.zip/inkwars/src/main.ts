import * as THREE from 'three';
import { CONFIG } from './config';
import { Arena } from './arena';
import { Paint } from './paint';
import { Actor, Sim } from './sim';
import { buildArenaView } from './arenaView';
import { ActorView } from './actorView';
import { Particles, ProjectileView } from './effects';
import { Nav } from './nav';
import { Bot } from './bots';

const PALETTE = [0xff2d95, 0xff8a00, 0xffd400, 0x7ddc1f, 0x00cfc1, 0x2f7bff, 0x9b4dff, 0xff3b30];
const STEP = 1 / 60;
const $ = (id: string) => document.getElementById(id)!;
const css = (hex: number) => '#' + hex.toString(16).padStart(6, '0');

// ── Szene ─────────────────────────────────────────────────────
const canvas = $('game') as HTMLCanvasElement;
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;

const scene = new THREE.Scene();
scene.background = new THREE.Color(0xeceef1);
scene.fog = new THREE.Fog(0xeceef1, 70, 190);
const camera = new THREE.PerspectiveCamera(CONFIG.camera.fov, 1, 0.1, 400);
camera.rotation.order = 'YXZ';

scene.add(new THREE.HemisphereLight(0xffffff, 0xd9dce2, 1.9));
const sun = new THREE.DirectionalLight(0xffffff, 1.5);
sun.position.set(-22, 40, 18);
sun.castShadow = true;
sun.shadow.mapSize.set(2048, 2048);
Object.assign(sun.shadow.camera, { left: -36, right: 36, top: 30, bottom: -30, near: 1, far: 100 });
sun.shadow.bias = -0.0008;
sun.shadow.radius = 5; // weiche Studioschatten
scene.add(sun);

const arena = new Arena();
const paint = new Paint(arena);
const sim = new Sim(arena, paint);
const nav = new Nav(arena);
scene.add(buildArenaView(arena, paint));

const teamColors = [new THREE.Color(), new THREE.Color(), new THREE.Color()];
const projView = new ProjectileView(teamColors);
const particles = new Particles();
scene.add(projView.mesh, particles.mesh);

// ── Zustand ───────────────────────────────────────────────────
type State = 'menu' | 'countdown' | 'playing' | 'ended';
let state: State = 'menu';
let mode = 1;
let colorIdx = 0;
let enemyIdx = 4;
let player: Actor | null = null;
let views: ActorView[] = [];
let bots: Bot[] = [];
let timeLeft = 0;
let countdown = 0;
let endT = 0;
let acc = 0;
let clock = 0;

// Kamera / Eingabe des Spielers
let yaw = -Math.PI / 2;
let pitch = -0.1;
let camDist = CONFIG.camera.distHuman;
const pivot = new THREE.Vector3();
const keys = new Set<string>();
let mouseDown = false;

// ── Menü ──────────────────────────────────────────────────────
function hue(hex: number): number {
  const hsl = { h: 0, s: 0, l: 0 };
  new THREE.Color(hex).getHSL(hsl);
  return hsl.h;
}
/** Gegnerfarbe: die Palettenfarbe, die am weitesten von der eigenen entfernt ist. */
function enemyFor(i: number): number {
  let best = 0;
  let bd = -1;
  PALETTE.forEach((c, j) => {
    let d = Math.abs(hue(c) - hue(PALETTE[i]));
    d = Math.min(d, 1 - d);
    if (d > bd) (bd = d), (best = j);
  });
  return best;
}
function refreshMenu() {
  enemyIdx = enemyFor(colorIdx);
  document.querySelectorAll<HTMLElement>('.sw').forEach((el, i) => el.classList.toggle('on', i === colorIdx));
  document.querySelectorAll<HTMLElement>('.mode').forEach((el) => el.classList.toggle('on', Number(el.dataset.mode) === mode));
  $('versus').innerHTML = `<span class="dot" style="background:${css(PALETTE[colorIdx])}"></span> Du &nbsp;gegen&nbsp; Gegner <span class="dot" style="background:${css(PALETTE[enemyIdx])}"></span>`;
  ($('start') as HTMLElement).style.background = css(PALETTE[colorIdx]);
}
PALETTE.forEach((c, i) => {
  const b = document.createElement('button');
  b.className = 'sw';
  b.style.background = css(c);
  b.onclick = () => {
    colorIdx = i;
    refreshMenu();
  };
  $('palette').appendChild(b);
});
document.querySelectorAll<HTMLElement>('.mode').forEach((el) => {
  el.onclick = () => {
    mode = Number(el.dataset.mode);
    refreshMenu();
  };
});
$('start').onclick = () => {
  startMatch();
  lockPointer();
};
$('again').onclick = () => {
  $('end').classList.add('hidden');
  $('menu').classList.remove('hidden');
  state = 'menu';
};
refreshMenu();

// ── Runde ─────────────────────────────────────────────────────
function startMatch() {
  for (const v of views) scene.remove(v.group);
  views = [];
  bots = [];
  sim.actors = [];
  sim.projectiles = [];
  sim.events = [];

  const c1 = PALETTE[colorIdx];
  const c2 = PALETTE[enemyIdx];
  teamColors[1].set(c1);
  teamColors[2].set(c2);
  paint.setColors(c1, c2);
  paint.reset();

  player = sim.addActor(1, 0, false);
  for (let i = 0; i < mode; i++) {
    if (i > 0) bots.push(new Bot(sim.addActor(1, i, true), sim, nav));
    bots.push(new Bot(sim.addActor(2, i, true), sim, nav));
  }
  for (const a of sim.actors) {
    const v = new ActorView(a, a.team === 1 ? c1 : c2);
    views.push(v);
    scene.add(v.group);
  }

  yaw = player.yaw;
  pitch = -0.1;
  pivot.copy(player.pos);
  timeLeft = CONFIG.match.duration;
  countdown = CONFIG.match.countdown;
  acc = 0;
  state = 'countdown';

  $('menu').classList.add('hidden');
  $('end').classList.add('hidden');
  $('hud').classList.remove('hidden');
  $('p1').style.background = css(c1);
  $('p2').style.background = css(c2);
  $('tankFill').style.background = css(c1);
  $('end1').style.color = css(c1);
  $('end2').style.color = css(c2);
}

function endMatch() {
  state = 'ended';
  endT = 0;
  sim.projectiles = [];
  document.exitPointerLock?.();
  $('hud').classList.add('hidden');
  $('endTitle').textContent = '';
}

// ── Eingabe ───────────────────────────────────────────────────
function lockPointer() {
  try {
    const p = canvas.requestPointerLock() as unknown as Promise<void> | undefined;
    p?.catch?.(() => {});
  } catch {
    /* ohne Pointer Lock geht es mit den Pfeiltasten weiter */
  }
}
const locked = () => document.pointerLockElement === canvas;
canvas.addEventListener('mousedown', (e) => {
  if (state === 'menu' || state === 'ended') return;
  if (!locked()) lockPointer();
  if (e.button === 0) mouseDown = true;
});
window.addEventListener('mouseup', (e) => {
  if (e.button === 0) mouseDown = false;
});
window.addEventListener('mousemove', (e) => {
  if (!locked()) return;
  yaw -= e.movementX * CONFIG.camera.mouseSens;
  pitch = Math.max(-1.2, Math.min(1.1, pitch - e.movementY * CONFIG.camera.mouseSens));
});
window.addEventListener('keydown', (e) => {
  keys.add(e.code);
  if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Tab'].includes(e.code)) e.preventDefault();
});
window.addEventListener('keyup', (e) => keys.delete(e.code));
window.addEventListener('blur', () => {
  keys.clear();
  mouseDown = false;
});

const fwd = new THREE.Vector3();
const target = new THREE.Vector3();
const muzzle = new THREE.Vector3();

/** Tastatur und Maus in das Input-Objekt der Spielfigur übersetzen. */
function playerInput(a: Actor, dt: number) {
  const C = CONFIG.camera;
  const k = (c: string) => (keys.has(c) ? 1 : 0);
  yaw += (k('ArrowLeft') - k('ArrowRight')) * C.keyTurn * dt;
  pitch = Math.max(-1.2, Math.min(1.1, pitch + (k('ArrowUp') - k('ArrowDown')) * C.keyTurn * 0.6 * dt));

  const f = k('KeyW') - k('KeyS');
  const s = k('KeyD') - k('KeyA');
  const inp = a.input;
  inp.moveX = -Math.sin(yaw) * f + Math.cos(yaw) * s;
  inp.moveZ = -Math.cos(yaw) * f - Math.sin(yaw) * s;
  inp.jump = keys.has('Space');
  inp.fish = keys.has('ShiftLeft') || keys.has('ShiftRight');
  inp.shoot = mouseDown || keys.has('KeyE');

  // Zielen: dorthin, wo das Fadenkreuz hinzeigt
  fwd.set(-Math.sin(yaw) * Math.cos(pitch), Math.sin(pitch), -Math.cos(yaw) * Math.cos(pitch));
  arena.raycast(camera.position, fwd, camDist + 1.5, 45, target);
  const ang = Sim.aimAngles(sim.muzzle(a, muzzle), target);
  inp.aimYaw = yaw;
  inp.aimPitch = ang.pitch;
}

// ── Kamera ────────────────────────────────────────────────────
const want = new THREE.Vector3();
const probe = new THREE.Vector3();
function followCamera(a: Actor, dt: number) {
  const C = CONFIG.camera;
  const m = a.morph;
  const height = C.heightHuman + (C.heightFish - C.heightHuman) * m;
  const shoulder = C.shoulder * (1 - m);
  want.set(a.pos.x + Math.cos(yaw) * shoulder, a.pos.y + height, a.pos.z - Math.sin(yaw) * shoulder);
  pivot.lerp(want, 1 - Math.exp(-dt * C.follow));
  fwd.set(-Math.sin(yaw) * Math.cos(pitch), Math.sin(pitch), -Math.cos(yaw) * Math.cos(pitch));

  // nicht durch Wände und Boden schauen
  const full = C.distHuman + (C.distFish - C.distHuman) * m;
  let dist = full;
  for (let i = 1; i <= 12; i++) {
    const t = (full * i) / 12;
    probe.copy(pivot).addScaledVector(fwd, -t);
    if (probe.y < arena.heightAt(probe.x, probe.z) + 0.3) {
      dist = Math.max(0.8, (full * (i - 1)) / 12);
      break;
    }
  }
  camDist += (dist - camDist) * (dist < camDist ? 1 : Math.min(1, dt * 6));
  camera.position.copy(pivot).addScaledVector(fwd, -camDist);
  camera.rotation.set(pitch, yaw, 0);
}

function topDownCamera(dt: number) {
  const tan = Math.tan((CONFIG.camera.fov * Math.PI) / 360);
  const h = Math.max((arena.D + 8) / (2 * tan), (arena.W + 8) / (2 * tan * camera.aspect));
  const k = 1 - Math.exp(-dt * 2.5);
  camera.position.lerp(want.set(0, h, 0.01), k);
  camera.quaternion.slerp(new THREE.Quaternion().setFromEuler(new THREE.Euler(-Math.PI / 2, 0, 0, 'YXZ')), k);
}

// ── HUD ───────────────────────────────────────────────────────
function hud() {
  if (!player) return;
  const t = Math.max(0, Math.ceil(timeLeft));
  $('timer').textContent = `${Math.floor(t / 60)}:${String(t % 60).padStart(2, '0')}`;
  const p1 = paint.percent(1);
  const p2 = paint.percent(2);
  $('p1').style.width = p1 + '%';
  $('p2').style.width = p2 + '%';
  $('pct1').textContent = p1.toFixed(1) + ' %';
  $('pct2').textContent = p2.toFixed(1) + ' %';
  $('tankFill').style.height = (player.tank / CONFIG.weapon.tank) * 100 + '%';
  $('tank').classList.toggle('refill', player.fish && player.inOwnInk && player.tank < CONFIG.weapon.tank);
  $('hpFill').style.width = Math.max(0, player.hp) + '%';
  $('hurt').style.opacity = String(player.alive ? (1 - player.hp / 100) * 0.9 : 0.6);
  $('cross').style.opacity = player.alive && !player.fish ? '1' : '0.25';

  let status = '';
  if (state === 'countdown') status = String(Math.ceil(countdown));
  else if (!player.alive) status = `Erwischt! ${Math.ceil(player.respawnT)}`;
  else if (timeLeft > CONFIG.match.duration - 1) status = 'LOS!';
  else if (timeLeft <= 10) status = String(t);
  $('status').textContent = status;

  let hint = '';
  if (!locked()) hint = 'Klick ins Spiel, um mit der Maus zu zielen';
  else if (player.alive && player.tank < CONFIG.weapon.shotCost) hint = 'Tank leer – Shift halten und im eigenen Wasser nachladen';
  $('hint').textContent = hint;
}

// ── Hauptschleife ─────────────────────────────────────────────
function simulate(dt: number) {
  if (!player) return;
  if (state === 'countdown') {
    countdown -= dt;
    playerInput(player, dt);
    player.yaw = yaw;
    if (countdown <= 0) state = 'playing';
  } else if (state === 'playing') {
    timeLeft -= dt;
    playerInput(player, dt);
    acc += dt;
    while (acc >= STEP) {
      for (const b of bots) b.think(STEP);
      sim.step(STEP);
      acc -= STEP;
    }
    if (timeLeft <= 0) endMatch();
  }
  for (const e of sim.events) {
    const c = teamColors[e.team];
    if (e.type === 'splash') particles.burst(e.x, e.y, e.z, c, 4, 3);
    else if (e.type === 'hit') particles.burst(e.x, e.y, e.z, c, 8, 4);
    else particles.burst(e.x, e.y, e.z, c, 50, 7);
  }
  sim.events.length = 0;
}

function resize() {
  const w = window.innerWidth;
  const h = window.innerHeight;
  renderer.setSize(w, h, false);
  camera.aspect = w / h;
  camera.updateProjectionMatrix();
}
window.addEventListener('resize', resize);
resize();

let last = performance.now();
function frame(now: number) {
  requestAnimationFrame(frame);
  const dt = Math.min(0.05, (now - last) / 1000);
  last = now;
  clock += dt;

  simulate(dt);
  for (const v of views) v.update(dt, 1);
  projView.update(sim.projectiles);
  particles.update(dt);

  if (state === 'menu') {
    camera.position.set(Math.cos(clock * 0.12) * 46, 24, Math.sin(clock * 0.12) * 36);
    camera.lookAt(0, 0, 0);
  } else if (state === 'ended') {
    endT += dt;
    topDownCamera(dt);
    if (endT > 1.6) {
      $('end').classList.remove('hidden');
      const k = Math.min(1, (endT - 1.6) / 2);
      const e = 1 - (1 - k) * (1 - k);
      const p1 = paint.percent(1);
      const p2 = paint.percent(2);
      $('end1').textContent = (p1 * e).toFixed(1) + ' %';
      $('end2').textContent = (p2 * e).toFixed(1) + ' %';
      if (k >= 1) $('endTitle').textContent = p1 > p2 ? 'Gewonnen!' : p1 < p2 ? 'Verloren' : 'Unentschieden';
    }
  } else if (player) {
    followCamera(player, dt);
    hud();
  }

  paint.flush();
  renderer.render(scene, camera);
}
requestAnimationFrame(frame);

// Zugriff für Tests in der Browser-Konsole
(window as unknown as Record<string, unknown>).__inkwars = {
  sim,
  paint,
  arena,
  get state() {
    return state;
  },
  get player() {
    return player;
  },
  get timeLeft() {
    return timeLeft;
  },
  set timeLeft(v: number) {
    timeLeft = v;
  },
  start: (m = 1, c = 0) => {
    mode = m;
    colorIdx = c;
    refreshMenu();
    startMatch();
  },
  /** Simulation ohne Bildschirm vorspulen. */
  advance: (seconds: number) => {
    for (let i = 0; i < seconds * 60; i++) simulate(STEP);
  },
  keys,
};
