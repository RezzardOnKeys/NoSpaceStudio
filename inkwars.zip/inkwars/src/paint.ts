import * as THREE from 'three';
import { CONFIG } from './config';
import { Arena, Shape } from './arena';

// Die Farbmaske: eine Draufsicht-Textur für alle begehbaren Flächen und
// je eine kleine Textur pro Wandfläche. Aus denselben Daten kommen
// Darstellung, die Abfrage "welche Farbe ist hier" und die Wertung.

export interface WallPaint {
  w: number;
  h: number;
  start: number; // Weltkoordinate, an der die Wand beginnt
  len: number;
  y0: number;
  height: number;
  team: Uint8Array;
  data: Uint8Array<ArrayBuffer>;
  texture: THREE.DataTexture;
  dirty: boolean;
}

function makeTexture(data: Uint8Array<ArrayBuffer>, w: number, h: number): THREE.DataTexture {
  const t = new THREE.DataTexture(data, w, h, THREE.RGBAFormat);
  t.colorSpace = THREE.SRGBColorSpace;
  t.magFilter = THREE.LinearFilter;
  t.minFilter = THREE.LinearFilter;
  t.needsUpdate = true;
  return t;
}

export class Paint {
  readonly tpm = CONFIG.arena.texelsPerMeter;
  readonly TW: number;
  readonly TH: number;
  readonly team: Uint8Array;
  readonly locked: Uint8Array;
  readonly heights: Float32Array;
  readonly data: Uint8Array<ArrayBuffer>;
  readonly texture: THREE.DataTexture;
  readonly counts = [0, 0, 0];
  readonly total: number;
  readonly walls = new Map<number, WallPaint>();
  private rgb: number[][] = [
    [0, 0, 0],
    [255, 0, 128],
    [0, 200, 200],
  ];
  private dirty = false;

  constructor(private arena: Arena) {
    this.TW = arena.W * this.tpm;
    this.TH = arena.D * this.tpm;
    this.total = this.TW * this.TH;
    this.team = new Uint8Array(this.total);
    this.locked = new Uint8Array(this.total);
    this.heights = new Float32Array(this.total);
    this.data = new Uint8Array(this.total * 4);
    this.texture = makeTexture(this.data, this.TW, this.TH);

    for (let iz = 0; iz < this.TH; iz++) {
      for (let ix = 0; ix < this.TW; ix++) {
        const x = (ix + 0.5) / this.tpm - arena.hw;
        const z = (iz + 0.5) / this.tpm - arena.hd;
        const i = iz * this.TW + ix;
        this.heights[i] = arena.heightAt(x, z);
        const s = arena.shapeAt(x, z);
        if (s && s.lock) this.locked[i] = s.lock;
      }
    }

    for (const s of arena.shapes) {
      if (s.kind !== 'box') continue;
      for (let face = 0; face < 4; face++) {
        const alongX = face >= 2;
        const start = alongX ? s.x0 : s.z0;
        const len = alongX ? s.x1 - s.x0 : s.z1 - s.z0;
        const height = s.h - s.y0;
        const w = Math.max(2, Math.round(len * this.tpm));
        const h = Math.max(2, Math.round(height * this.tpm));
        const data = new Uint8Array(w * h * 4);
        this.walls.set(s.id * 4 + face, {
          w,
          h,
          start,
          len,
          y0: s.y0,
          height,
          team: new Uint8Array(w * h),
          data,
          texture: makeTexture(data, w, h),
          dirty: false,
        });
      }
    }
    this.reset();
  }

  setColors(c1: number, c2: number) {
    const toRgb = (hex: number) => [(hex >> 16) & 255, (hex >> 8) & 255, hex & 255];
    this.rgb = [[0, 0, 0], toRgb(c1), toRgb(c2)];
  }

  reset() {
    this.counts[0] = this.total;
    this.counts[1] = 0;
    this.counts[2] = 0;
    for (let i = 0; i < this.total; i++) {
      const t = this.locked[i];
      this.team[i] = t;
      if (t) {
        this.counts[0]--;
        this.counts[t]++;
      }
      this.write(this.data, i, t);
    }
    this.dirty = true;
    for (const w of this.walls.values()) {
      w.team.fill(0);
      w.data.fill(0);
      w.dirty = true;
    }
  }

  private write(data: Uint8Array, i: number, team: number) {
    const c = this.rgb[team];
    const o = i * 4;
    data[o] = c[0];
    data[o + 1] = c[1];
    data[o + 2] = c[2];
    data[o + 3] = team ? 255 : 0;
  }

  /** Farbklecks auf begehbarer Fläche. yRef verhindert, dass die Farbe über Kanten auf andere Ebenen springt. */
  paintFloor(x: number, z: number, r: number, team: number, yRef: number) {
    const cx = (x + this.arena.hw) * this.tpm;
    const cz = (z + this.arena.hd) * this.tpm;
    const rr = r * this.tpm;
    const phase = Math.random() * 6.28;
    const x0 = Math.max(0, Math.floor(cx - rr));
    const x1 = Math.min(this.TW - 1, Math.ceil(cx + rr));
    const z0 = Math.max(0, Math.floor(cz - rr));
    const z1 = Math.min(this.TH - 1, Math.ceil(cz + rr));
    for (let iz = z0; iz <= z1; iz++) {
      for (let ix = x0; ix <= x1; ix++) {
        const dx = ix + 0.5 - cx;
        const dz = iz + 0.5 - cz;
        const d2 = dx * dx + dz * dz;
        if (d2 > rr * rr) continue;
        // unregelmäßiger Rand, damit es nach Klecks aussieht
        const rad = rr * (0.8 + 0.2 * Math.sin(Math.atan2(dz, dx) * 5 + phase));
        if (d2 > rad * rad) continue;
        const i = iz * this.TW + ix;
        if (Math.abs(this.heights[i] - yRef) > 0.75) continue;
        if (this.locked[i] && this.locked[i] !== team) continue;
        const old = this.team[i];
        if (old === team) continue;
        this.counts[old]--;
        this.counts[team]++;
        this.team[i] = team;
        this.write(this.data, i, team);
        this.dirty = true;
      }
    }
  }

  floorTeamAt(x: number, z: number): number {
    const ix = Math.floor((x + this.arena.hw) * this.tpm);
    const iz = Math.floor((z + this.arena.hd) * this.tpm);
    if (ix < 0 || iz < 0 || ix >= this.TW || iz >= this.TH) return 0;
    return this.team[iz * this.TW + ix];
  }

  wall(s: Shape, face: number): WallPaint | undefined {
    return this.walls.get(s.id * 4 + face);
  }

  paintWall(s: Shape, face: number, along: number, y: number, r: number, team: number) {
    const w = this.wall(s, face);
    if (!w) return;
    const cu = ((along - w.start) / w.len) * w.w;
    const cv = ((y - w.y0) / w.height) * w.h;
    const rr = r * this.tpm;
    const phase = Math.random() * 6.28;
    const u0 = Math.max(0, Math.floor(cu - rr));
    const u1 = Math.min(w.w - 1, Math.ceil(cu + rr));
    const v0 = Math.max(0, Math.floor(cv - rr));
    const v1 = Math.min(w.h - 1, Math.ceil(cv + rr));
    for (let iv = v0; iv <= v1; iv++) {
      for (let iu = u0; iu <= u1; iu++) {
        const du = iu + 0.5 - cu;
        const dv = iv + 0.5 - cv;
        const d2 = du * du + dv * dv;
        const rad = rr * (0.8 + 0.2 * Math.sin(Math.atan2(dv, du) * 5 + phase));
        if (d2 > rad * rad) continue;
        const i = iv * w.w + iu;
        if (w.team[i] === team) continue;
        w.team[i] = team;
        this.write(w.data, i, team);
        w.dirty = true;
      }
    }
  }

  wallTeamAt(s: Shape, face: number, along: number, y: number): number {
    const w = this.wall(s, face);
    if (!w) return 0;
    const iu = Math.min(w.w - 1, Math.max(0, Math.floor(((along - w.start) / w.len) * w.w)));
    const iv = Math.min(w.h - 1, Math.max(0, Math.floor(((y - w.y0) / w.height) * w.h)));
    return w.team[iv * w.w + iu];
  }

  /** Flächenanteil eines Teams in Prozent. */
  percent(team: number): number {
    return (this.counts[team] / this.total) * 100;
  }

  /** Geänderte Texturen einmal pro Bild zur Grafikkarte schicken. */
  flush() {
    if (this.dirty) {
      this.texture.needsUpdate = true;
      this.dirty = false;
    }
    for (const w of this.walls.values()) {
      if (w.dirty) {
        w.texture.needsUpdate = true;
        w.dirty = false;
      }
    }
  }
}
