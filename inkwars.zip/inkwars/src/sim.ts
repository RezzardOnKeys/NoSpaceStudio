import * as THREE from 'three';
import { CONFIG } from './config';
import { Arena } from './arena';
import { Paint } from './paint';

// Die Simulation kennt weder Tastatur noch Bildschirm. Jede Figur bekommt
// pro Schritt nur ein Input-Objekt – egal ob es von einem Menschen, einem
// Bot oder später aus dem Netzwerk stammt.

export interface Input {
  moveX: number; // Wunschrichtung in Weltkoordinaten
  moveZ: number;
  aimYaw: number;
  aimPitch: number;
  shoot: boolean;
  jump: boolean;
  fish: boolean;
}

export const emptyInput = (): Input => ({ moveX: 0, moveZ: 0, aimYaw: 0, aimPitch: 0, shoot: false, jump: false, fish: false });

export class Actor {
  pos = new THREE.Vector3();
  vel = new THREE.Vector3();
  yaw = 0;
  input = emptyInput();
  fish = false;
  morph = 0; // 0 = Mensch, 1 = Fisch
  grounded = true;
  climbing = false;
  inOwnInk = false;
  inEnemyInk = false;
  tank = CONFIG.weapon.tank;
  hp = CONFIG.actor.hp;
  alive = true;
  respawnT = 0;
  invuln = 0;
  kills = 0;
  private fireT = 0;
  hitT = 99;
  private airT = 0;
  private canJump = true;
  private prevJump = false;

  constructor(
    public id: number,
    public team: 1 | 2,
    public slot: number,
    public isBot: boolean,
  ) {}

  /** Als Fisch im eigenen Wasser: für Gegner unsichtbar. */
  get submerged(): boolean {
    return this.alive && this.fish && this.inOwnInk && this.morph > 0.7;
  }

  // Zugriff für die Simulation
  _s() {
    return this as unknown as { fireT: number; airT: number; canJump: boolean; prevJump: boolean };
  }
}

export interface Projectile {
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  team: 1 | 2;
  owner: Actor;
  life: number;
  dripT: number;
}

export type SimEvent =
  | { type: 'splash'; x: number; y: number; z: number; team: number }
  | { type: 'hit'; x: number; y: number; z: number; team: number; victim: Actor }
  | { type: 'death'; x: number; y: number; z: number; team: number; victim: Actor; killer: Actor };

const prev = new THREE.Vector3();

export class Sim {
  actors: Actor[] = [];
  projectiles: Projectile[] = [];
  events: SimEvent[] = [];

  constructor(
    public arena: Arena,
    public paint: Paint,
  ) {}

  addActor(team: 1 | 2, slot: number, isBot: boolean): Actor {
    const a = new Actor(this.actors.length, team, slot, isBot);
    this.actors.push(a);
    this.respawn(a);
    a.invuln = 0;
    return a;
  }

  respawn(a: Actor) {
    const s = this.arena.spawn(a.team, a.slot);
    a.pos.set(s.x, s.y, s.z);
    a.vel.set(0, 0, 0);
    a.yaw = s.yaw;
    a.input.aimYaw = s.yaw;
    a.input.aimPitch = 0;
    a.hp = CONFIG.actor.hp;
    a.tank = CONFIG.weapon.tank;
    a.alive = true;
    a.fish = false;
    a.morph = 0;
    a.grounded = true;
    a.climbing = false;
    a.invuln = CONFIG.actor.invulnTime;
  }

  muzzle(a: Actor, out: THREE.Vector3): THREE.Vector3 {
    const y = a.input.aimYaw;
    return out.set(
      a.pos.x - Math.sin(y) * 0.55 + Math.cos(y) * 0.28,
      a.pos.y + 1.2,
      a.pos.z - Math.cos(y) * 0.55 - Math.sin(y) * 0.28,
    );
  }

  /** Winkel, mit denen ein Schuss von `from` aus bei `to` landet (Fall des Wassers eingerechnet). */
  static aimAngles(from: THREE.Vector3, to: THREE.Vector3): { yaw: number; pitch: number } {
    const W = CONFIG.weapon;
    const dx = to.x - from.x;
    const dy = to.y - from.y;
    const dz = to.z - from.z;
    const dh = Math.hypot(dx, dz);
    const t = Math.min(Math.hypot(dh, dy), W.aimRange) / W.speed;
    const drop = 0.5 * W.gravity * t * t;
    return { yaw: Math.atan2(-dx, -dz), pitch: Math.atan2(dy + drop, Math.max(dh, 0.001)) };
  }

  step(dt: number) {
    for (const a of this.actors) this.updateActor(a, dt);
    this.updateProjectiles(dt);
  }

  // ── Figuren ────────────────────────────────────────────────
  private updateActor(a: Actor, dt: number) {
    const M = CONFIG.move;
    const W = CONFIG.weapon;
    const s = a._s();
    if (!a.alive) {
      a.respawnT -= dt;
      if (a.respawnT <= 0) this.respawn(a);
      return;
    }
    const inp = a.input;
    a.invuln = Math.max(0, a.invuln - dt);
    s.fireT -= dt;
    a.hitT += dt;

    a.fish = inp.fish;
    a.morph = Math.min(1, Math.max(0, a.morph + ((a.fish ? 1 : -1) * dt) / M.morphTime));

    // Worin steht die Figur gerade?
    const ink = a.grounded ? this.paint.floorTeamAt(a.pos.x, a.pos.z) : 0;
    a.inOwnInk = ink === a.team || a.climbing;
    a.inEnemyInk = ink !== 0 && ink !== a.team;

    const P = a.fish ? (a.inOwnInk ? M.fishInk : M.fishDry) : M.human;
    const maxSpeed = P.maxSpeed * (a.inEnemyInk ? M.enemyInkFactor : 1);

    let mx = inp.moveX;
    let mz = inp.moveZ;
    const len = Math.hypot(mx, mz);
    if (len > 1) {
      mx /= len;
      mz /= len;
    }

    if (a.grounded) {
      // Geschwindigkeit nähert sich dem Wunsch mit begrenzter Beschleunigung an:
      // das ergibt Anlaufen, Ausrollen und Trägheit in Kurven.
      const dvx = mx * maxSpeed - a.vel.x;
      const dvz = mz * maxSpeed - a.vel.z;
      const d = Math.hypot(dvx, dvz);
      const rate = (len > 0.01 ? P.accel : P.decel) * dt;
      if (d <= rate) {
        a.vel.x += dvx;
        a.vel.z += dvz;
      } else {
        a.vel.x += (dvx / d) * rate;
        a.vel.z += (dvz / d) * rate;
      }
    } else if (len > 0.01) {
      // In der Luft: nur wenig Kontrolle, vorhandener Schwung bleibt.
      const sp0 = Math.hypot(a.vel.x, a.vel.z);
      a.vel.x += mx * M.airAccel * dt;
      a.vel.z += mz * M.airAccel * dt;
      const sp1 = Math.hypot(a.vel.x, a.vel.z);
      const cap = Math.max(sp0, M.airMaxSpeed);
      if (sp1 > cap) {
        a.vel.x *= cap / sp1;
        a.vel.z *= cap / sp1;
      }
    }

    // Springen
    s.airT = a.grounded ? 0 : s.airT + dt;
    const jumpPressed = inp.jump && !s.prevJump;
    s.prevJump = inp.jump;
    if (jumpPressed && s.canJump && s.airT < M.coyoteTime) {
      a.vel.y = P.jumpSpeed;
      if (a.fish && a.inOwnInk) {
        a.vel.x *= M.fishJumpBoost;
        a.vel.z *= M.fishJumpBoost;
      }
      a.grounded = false;
      s.canJump = false;
    }

    // Horizontal bewegen, Achse für Achse, gegen Wände prüfen
    const r = M.radius;
    const feet = a.pos.y;
    const lim = feet + M.stepHeight;
    a.climbing = false;
    const ar = this.arena;

    if (a.vel.x !== 0) {
      const sg = Math.sign(a.vel.x);
      const nx = a.pos.x + a.vel.x * dt;
      const px = nx + sg * r;
      const z = a.pos.z;
      const hm = Math.max(ar.heightAt(px, z - r * 0.7), ar.heightAt(px, z), ar.heightAt(px, z + r * 0.7));
      if (hm > lim) {
        if (a.fish && this.ownWall(a, px, z, sg > 0 ? 0 : 1, z)) a.climbing = true;
        a.vel.x = 0;
      } else a.pos.x = nx;
    }
    if (a.vel.z !== 0) {
      const sg = Math.sign(a.vel.z);
      const nz = a.pos.z + a.vel.z * dt;
      const pz = nz + sg * r;
      const x = a.pos.x;
      const hm = Math.max(ar.heightAt(x - r * 0.7, pz), ar.heightAt(x, pz), ar.heightAt(x + r * 0.7, pz));
      if (hm > lim) {
        if (a.fish && this.ownWall(a, x, pz, sg > 0 ? 2 : 3, x)) a.climbing = true;
        a.vel.z = 0;
      } else a.pos.z = nz;
    }

    // Vertikal
    const wasGrounded = a.grounded;
    if (a.climbing) a.vel.y = M.climbSpeed;
    else a.vel.y -= M.gravity * dt;
    a.pos.y += a.vel.y * dt;
    const gh = ar.heightAt(a.pos.x, a.pos.z);
    if (a.pos.y <= gh) {
      a.pos.y = gh;
      if (a.vel.y < 0) a.vel.y = 0;
      a.grounded = true;
    } else if (wasGrounded && a.vel.y <= 0 && a.pos.y - gh < M.stepHeight) {
      a.pos.y = gh; // an Rampen und kleinen Stufen am Boden bleiben
      a.vel.y = 0;
      a.grounded = true;
    } else a.grounded = false;
    if (a.grounded) s.canJump = true;

    // Blickrichtung
    if (a.morph < 0.5) a.yaw = inp.aimYaw;
    else {
      const sp = Math.hypot(a.vel.x, a.vel.z);
      if (sp > 0.5) {
        const target = Math.atan2(-a.vel.x, -a.vel.z);
        let d = target - a.yaw;
        d = Math.atan2(Math.sin(d), Math.cos(d));
        a.yaw += d * Math.min(1, M.fishTurnRate * dt);
      }
    }

    // Schießen und Nachladen
    if (!a.fish && a.morph < 0.3 && inp.shoot && s.fireT <= 0 && a.tank >= W.shotCost) {
      s.fireT = W.fireInterval;
      a.tank -= W.shotCost;
      const p = inp.aimPitch + (Math.random() - 0.5) * 2 * W.spread;
      const y = inp.aimYaw + (Math.random() - 0.5) * 2 * W.spread;
      const cp = Math.cos(p);
      this.projectiles.push({
        pos: this.muzzle(a, new THREE.Vector3()),
        vel: new THREE.Vector3(-Math.sin(y) * cp * W.speed, Math.sin(p) * W.speed, -Math.cos(y) * cp * W.speed),
        team: a.team,
        owner: a,
        life: W.maxLife,
        dripT: W.dripInterval * 0.5,
      });
    }
    if (a.fish && a.inOwnInk) a.tank = Math.min(W.tank, a.tank + W.refillPerSec * dt);
    if (a.hitT > CONFIG.actor.regenDelay) a.hp = Math.min(CONFIG.actor.hp, a.hp + CONFIG.actor.regenPerSec * dt);
  }

  /** Ist die Wand vor dem Fisch in der eigenen Farbe? */
  private ownWall(a: Actor, px: number, pz: number, face: number, along: number): boolean {
    const shape = this.arena.shapeAt(px, pz);
    if (!shape || shape.kind !== 'box') return false;
    return this.paint.wallTeamAt(shape, face, along, a.pos.y + 0.25) === a.team;
  }

  // ── Wasser ─────────────────────────────────────────────────
  private updateProjectiles(dt: number) {
    const W = CONFIG.weapon;
    const ar = this.arena;
    const h = dt / 2;
    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const p = this.projectiles[i];
      p.life -= dt;
      let dead = p.life <= 0;
      for (let sub = 0; sub < 2 && !dead; sub++) {
        prev.copy(p.pos);
        p.vel.y -= W.gravity * h;
        p.pos.addScaledVector(p.vel, h);
        if (!ar.inBounds(p.pos.x, p.pos.z)) {
          dead = true;
          break;
        }
        for (const a of this.actors) {
          if (!a.alive || a.team === p.team || a.invuln > 0) continue;
          if (this.hits(p.pos, a)) {
            this.damage(a, p);
            dead = true;
            break;
          }
        }
        if (dead) break;
        const gh = ar.heightAt(p.pos.x, p.pos.z);
        if (p.pos.y <= gh) {
          this.impact(p, gh);
          dead = true;
          break;
        }
        p.dripT -= h;
        if (p.dripT <= 0) {
          p.dripT = W.dripInterval;
          if (p.pos.y - gh < 5) this.paint.paintFloor(p.pos.x, p.pos.z, W.dripRadius, p.team, gh);
        }
      }
      if (dead) {
        this.projectiles[i] = this.projectiles[this.projectiles.length - 1];
        this.projectiles.pop();
      }
    }
  }

  private hits(p: THREE.Vector3, a: Actor): boolean {
    const dx = p.x - a.pos.x;
    const dz = p.z - a.pos.z;
    if (a.morph > 0.5) {
      const dy = p.y - (a.pos.y + 0.28);
      return dx * dx + dy * dy + dz * dz < 0.5 * 0.5;
    }
    const cy = Math.min(a.pos.y + 1.5, Math.max(a.pos.y + 0.3, p.y));
    const dy = p.y - cy;
    return dx * dx + dy * dy + dz * dz < 0.55 * 0.55;
  }

  private damage(a: Actor, p: Projectile) {
    a.hp -= CONFIG.weapon.damage;
    a.hitT = 0;
    this.events.push({ type: 'hit', x: p.pos.x, y: p.pos.y, z: p.pos.z, team: p.team, victim: a });
    if (a.hp <= 0) {
      a.alive = false;
      a.respawnT = CONFIG.actor.respawnTime;
      p.owner.kills++;
      const gh = this.arena.heightAt(a.pos.x, a.pos.z);
      this.paint.paintFloor(a.pos.x, a.pos.z, 2.6, p.team, gh);
      this.events.push({ type: 'death', x: a.pos.x, y: a.pos.y + 0.8, z: a.pos.z, team: p.team, victim: a, killer: p.owner });
    }
  }

  private impact(p: Projectile, gh: number) {
    const W = CONFIG.weapon;
    if (prev.y >= gh) {
      // von oben auf eine Fläche
      this.paint.paintFloor(p.pos.x, p.pos.z, W.floorRadius, p.team, gh);
      this.events.push({ type: 'splash', x: p.pos.x, y: gh, z: p.pos.z, team: p.team });
      return;
    }
    // seitlich gegen eine Wand
    const s = this.arena.shapeAt(p.pos.x, p.pos.z);
    if (s && s.kind === 'box') {
      let face: number;
      let along: number;
      if (prev.x < s.x0) (face = 0), (along = p.pos.z);
      else if (prev.x > s.x1) (face = 1), (along = p.pos.z);
      else if (prev.z < s.z0) (face = 2), (along = p.pos.x);
      else (face = 3), (along = p.pos.x);
      this.paint.paintWall(s, face, along, p.pos.y, W.wallRadius, p.team);
    }
    this.paint.paintFloor(prev.x, prev.z, 0.6, p.team, this.arena.heightAt(prev.x, prev.z));
    this.events.push({ type: 'splash', x: prev.x, y: prev.y, z: prev.z, team: p.team });
  }
}
