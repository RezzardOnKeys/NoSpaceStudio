import * as THREE from 'three';
import { CONFIG } from './config';

// dir = Richtung, in die eine Rampe ansteigt: 0:+x 1:-x 2:+z 3:-z
export interface Shape {
  id: number;
  kind: 'box' | 'ramp';
  x0: number;
  x1: number;
  z0: number;
  z1: number;
  y0: number; // Unterkante
  h: number; // Oberkante (bei Rampen: hohes Ende)
  hLow: number; // nur Rampe: niedriges Ende
  dir: 0 | 1 | 2 | 3;
  color: number;
  lock: 0 | 1 | 2; // Basis: nur dieses Team kann hier färben
}

export function shapeHeight(s: Shape, x: number, z: number): number {
  if (s.kind === 'box') return s.h;
  let t = 0;
  if (s.dir === 0) t = (x - s.x0) / (s.x1 - s.x0);
  else if (s.dir === 1) t = (s.x1 - x) / (s.x1 - s.x0);
  else if (s.dir === 2) t = (z - s.z0) / (s.z1 - s.z0);
  else t = (s.z1 - z) / (s.z1 - s.z0);
  t = Math.min(1, Math.max(0, t));
  return s.hLow + (s.h - s.hLow) * t;
}

type Half = Omit<Shape, 'id'>;

const C = {
  base: 0xf7f6f2,
  mint: 0xbfdcc0, // Salbeigrün
  sky: 0xdde1e7, // Hellgrau
  rose: 0xf4bcb6, // Lachs
  lilac: 0xe9e4da, // Sandweiß
  sand: 0xf3dcc0,
};

function box(x0: number, x1: number, z0: number, z1: number, h: number, color: number, y0 = 0, lock: 0 | 1 | 2 = 0): Half {
  return { kind: 'box', x0, x1, z0, z1, y0, h, hLow: h, dir: 0, color, lock };
}
function ramp(x0: number, x1: number, z0: number, z1: number, h: number, dir: 0 | 1 | 2 | 3, color: number): Half {
  return { kind: 'ramp', x0, x1, z0, z1, y0: 0, h, hLow: 0, dir, color, lock: 0 };
}
function mirror(s: Half): Half {
  const dir = ([1, 0, 3, 2] as const)[s.dir];
  return { ...s, x0: -s.x1, x1: -s.x0, z0: -s.z1, z1: -s.z0, dir, lock: s.lock === 1 ? 2 : s.lock };
}

export class Arena {
  readonly W = CONFIG.arena.width;
  readonly D = CONFIG.arena.depth;
  readonly hw = this.W / 2;
  readonly hd = this.D / 2;
  readonly shapes: Shape[] = [];

  constructor() {
    // Eine Hälfte wird gebaut, die andere punktgespiegelt – so ist die Karte fair.
    const half: Half[] = [
      box(-28, -22, -6, 6, 1.2, C.base, 0, 1), // Basis
      ramp(-22, -18, -3, 3, 1.2, 1, C.sand),
      box(-14, -12, -11, -6, 1.6, C.rose),
      box(-9, -7, 2, 5, 1.2, C.lilac),
      box(-16, -10, 8, 14, 1.5, C.sky), // Seitenplattform
      ramp(-15, -11, 4, 8, 1.5, 2, C.sand),
      box(-20, -18, -14, -12, 3, C.mint), // Säule
      box(-3, 3, 11, 12, 1.4, C.rose),
      box(-8, -6, -10, -8, 1.3, C.mint),
      ramp(5, 11, -2, 2, 2, 1, C.sand), // Aufgang zur Mitte
    ];
    const all: Half[] = [
      ...half,
      ...half.map(mirror),
      box(-5, 5, -4, 4, 2, C.sky), // Mittelplattform
      box(-2, 2, -2, 2, 3.6, C.lilac, 2), // Turm darauf
    ];
    all.forEach((s, i) => this.shapes.push({ ...s, id: i }));
  }

  spawn(team: number, slot: number): { x: number; y: number; z: number; yaw: number } {
    const side = team === 1 ? -1 : 1;
    return { x: side * 25, y: 1.2, z: slot === 0 ? -2 * side : 2 * side, yaw: (side * Math.PI) / 2 };
  }

  inBounds(x: number, z: number): boolean {
    return x >= -this.hw && x <= this.hw && z >= -this.hd && z <= this.hd;
  }

  heightAt(x: number, z: number): number {
    if (!this.inBounds(x, z)) return 100;
    let h = 0;
    for (const s of this.shapes) {
      if (x >= s.x0 && x <= s.x1 && z >= s.z0 && z <= s.z1) {
        const sh = shapeHeight(s, x, z);
        if (sh > h) h = sh;
      }
    }
    return h;
  }

  /** Das höchste Bauteil an dieser Stelle (null = blanker Boden). */
  shapeAt(x: number, z: number): Shape | null {
    let h = 0;
    let best: Shape | null = null;
    for (const s of this.shapes) {
      if (x >= s.x0 && x <= s.x1 && z >= s.z0 && z <= s.z1) {
        const sh = shapeHeight(s, x, z);
        if (sh > h) {
          h = sh;
          best = s;
        }
      }
    }
    return best;
  }

  /** Freie Sicht zwischen zwei Punkten? */
  rayClear(ax: number, ay: number, az: number, bx: number, by: number, bz: number): boolean {
    const d = Math.hypot(bx - ax, by - ay, bz - az);
    const n = Math.max(1, Math.ceil(d / 0.4));
    for (let i = 1; i < n; i++) {
      const t = i / n;
      if (ay + (by - ay) * t < this.heightAt(ax + (bx - ax) * t, az + (bz - az) * t)) return false;
    }
    return true;
  }

  /** Strahl gegen das Gelände. Liefert den Trefferpunkt oder den Endpunkt. */
  raycast(o: THREE.Vector3, d: THREE.Vector3, tMin: number, tMax: number, out: THREE.Vector3): boolean {
    for (let t = tMin; t <= tMax; t += 0.25) {
      out.set(o.x + d.x * t, o.y + d.y * t, o.z + d.z * t);
      if (out.y <= this.heightAt(out.x, out.z)) return true;
    }
    out.set(o.x + d.x * tMax, o.y + d.y * tMax, o.z + d.z * tMax);
    return false;
  }
}
