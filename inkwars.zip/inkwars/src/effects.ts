import * as THREE from 'three';
import { Projectile } from './sim';

const dummy = new THREE.Object3D();
const col = new THREE.Color();

/** Fliegendes Wasser. */
export class ProjectileView {
  mesh: THREE.InstancedMesh;
  private max = 500;
  constructor(private colors: THREE.Color[]) {
    this.mesh = new THREE.InstancedMesh(new THREE.SphereGeometry(0.14, 8, 6), new THREE.MeshLambertMaterial(), this.max);
    this.mesh.setColorAt(0, col.set(0xffffff));
    this.mesh.count = 0;
    this.mesh.frustumCulled = false;
  }
  update(list: Projectile[]) {
    const n = Math.min(list.length, this.max);
    for (let i = 0; i < n; i++) {
      const p = list[i];
      dummy.position.copy(p.pos);
      dummy.scale.set(1, 1, 1);
      dummy.updateMatrix();
      this.mesh.setMatrixAt(i, dummy.matrix);
      this.mesh.setColorAt(i, this.colors[p.team]);
    }
    this.mesh.count = n;
    this.mesh.instanceMatrix.needsUpdate = true;
    if (this.mesh.instanceColor) this.mesh.instanceColor.needsUpdate = true;
  }
}

/** Spritzer bei Einschlägen und Treffern. */
export class Particles {
  mesh: THREE.InstancedMesh;
  private max = 600;
  private pos = new Float32Array(this.max * 3);
  private vel = new Float32Array(this.max * 3);
  private life = new Float32Array(this.max);
  private size = new Float32Array(this.max);
  private next = 0;

  constructor() {
    this.mesh = new THREE.InstancedMesh(new THREE.SphereGeometry(0.1, 6, 5), new THREE.MeshLambertMaterial(), this.max);
    this.mesh.frustumCulled = false;
    dummy.scale.set(0, 0, 0);
    dummy.updateMatrix();
    for (let i = 0; i < this.max; i++) {
      this.mesh.setMatrixAt(i, dummy.matrix);
      this.mesh.setColorAt(i, col.set(0xffffff));
    }
  }

  burst(x: number, y: number, z: number, color: THREE.Color, count: number, power: number) {
    for (let k = 0; k < count; k++) {
      const i = this.next;
      this.next = (this.next + 1) % this.max;
      const a = Math.random() * 6.28;
      const s = power * (0.3 + Math.random() * 0.7);
      this.pos[i * 3] = x;
      this.pos[i * 3 + 1] = y + 0.1;
      this.pos[i * 3 + 2] = z;
      this.vel[i * 3] = Math.cos(a) * s;
      this.vel[i * 3 + 1] = power * (0.5 + Math.random() * 0.9);
      this.vel[i * 3 + 2] = Math.sin(a) * s;
      this.life[i] = 0.35 + Math.random() * 0.4;
      this.size[i] = 0.6 + Math.random() * 1.2;
      this.mesh.setColorAt(i, color);
    }
    if (this.mesh.instanceColor) this.mesh.instanceColor.needsUpdate = true;
  }

  update(dt: number) {
    for (let i = 0; i < this.max; i++) {
      if (this.life[i] <= 0) continue;
      this.life[i] -= dt;
      this.vel[i * 3 + 1] -= 18 * dt;
      this.pos[i * 3] += this.vel[i * 3] * dt;
      this.pos[i * 3 + 1] += this.vel[i * 3 + 1] * dt;
      this.pos[i * 3 + 2] += this.vel[i * 3 + 2] * dt;
      const s = this.life[i] > 0 ? this.size[i] * Math.min(1, this.life[i] * 5) : 0;
      dummy.position.set(this.pos[i * 3], this.pos[i * 3 + 1], this.pos[i * 3 + 2]);
      dummy.scale.set(s, s, s);
      dummy.updateMatrix();
      this.mesh.setMatrixAt(i, dummy.matrix);
    }
    this.mesh.instanceMatrix.needsUpdate = true;
  }
}
