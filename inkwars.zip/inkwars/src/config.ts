// Alle Stellschrauben des Spiels an einem Ort.
// Einheiten: Meter, Sekunden, Meter pro Sekunde.

export const CONFIG = {
  arena: {
    width: 56,
    depth: 36,
    texelsPerMeter: 8, // Auflösung der Farbmaske
  },

  // ── Movement ────────────────────────────────────────────────
  move: {
    gravity: 22,
    radius: 0.4, // Körperradius für Kollisionen
    stepHeight: 0.4, // Kanten bis zu dieser Höhe werden ohne Sprung genommen
    coyoteTime: 0.1, // so lange darf man nach einer Kante noch abspringen
    morphTime: 0.14, // Dauer der Verwandlung Mensch <-> Fisch

    // Menschform
    human: { maxSpeed: 6.2, accel: 26, decel: 22, jumpSpeed: 7.4 },
    // Fischform im eigenen Wasser: schnell, gleitet lange nach
    fishInk: { maxSpeed: 12.5, accel: 30, decel: 7, jumpSpeed: 8.2 },
    // Fischform auf dem Trockenen: zappelt nur
    fishDry: { maxSpeed: 2.0, accel: 12, decel: 16, jumpSpeed: 4.0 },

    fishJumpBoost: 1.12, // Schwung-Bonus beim Sprung aus dem eigenen Wasser
    enemyInkFactor: 0.4, // Tempo-Faktor in gegnerischem Wasser
    airAccel: 9, // Steuerbarkeit in der Luft
    airMaxSpeed: 6.2, // bis zu diesem Tempo kann man in der Luft beschleunigen
    climbSpeed: 7, // Wand hochschwimmen
    fishTurnRate: 12, // wie schnell der Fisch sich in Bewegungsrichtung dreht
  },

  // ── Wasserpistole ───────────────────────────────────────────
  weapon: {
    tank: 100,
    shotCost: 2.2,
    fireInterval: 0.1,
    speed: 22,
    gravity: 18,
    spread: 0.035,
    damage: 22,
    floorRadius: 1.15, // Klecks am Einschlag
    wallRadius: 0.9,
    dripRadius: 0.5, // Tropfspur unter der Flugbahn
    dripInterval: 0.1,
    refillPerSec: 50,
    maxLife: 2.5,
    aimRange: 18, // bis hierhin wird der Fall des Wassers ausgeglichen
  },

  actor: {
    hp: 100,
    regenDelay: 3,
    regenPerSec: 40,
    respawnTime: 3,
    invulnTime: 1.5,
  },

  match: {
    duration: 180,
    countdown: 3,
  },

  camera: {
    fov: 62,
    distHuman: 5.0,
    distFish: 6.2,
    heightHuman: 1.6,
    heightFish: 0.9,
    shoulder: 0.9,
    follow: 16, // je höher, desto direkter folgt die Kamera
    mouseSens: 0.0023,
    keyTurn: 2.2,
  },
};
